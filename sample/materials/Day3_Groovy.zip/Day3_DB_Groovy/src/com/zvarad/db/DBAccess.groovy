package com.zvarad.db

import groovy.sql.Sql;

class DBAccess {

	static main(args) {
		
		def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')
		
		//db.execute("CREATE TABLE GROOVYTEST (groovyid int not null, name varchar(100),primary key(groovyid))");
		
		
		

	
	}

}
