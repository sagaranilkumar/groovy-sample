// requires hsqldb.jar in classpath
import groovy.sql.Sql

 def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver') 

/*def getDb(){                                            //#1
    if (dbHandle) return dbHandle
    def source = new org.hsqldb.jdbc.jdbcDataSource()
    source.database = 'jdbc:hsqldb:mem:GIA'
    source.user = 'sa'
    source.password = ''
    dbHandle = new Sql(source)
    return dbHandle
}*/
 
 
def reset() {
  def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')	                                           //#2
    db.execute '''
               CREATE TABLE Athlete (
            athleteId   int not null auto_increment,
            firstname   VARCHAR(64),
            lastname    VARCHAR(64),
            dateOfBirth DATE,primary key(athleteId)
        );
       
    '''
	db.close();
}
def create(firstname, lastname, dateOfBirth) {          //#3
	
	def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')	                                           //#2
    db.execute """
        INSERT INTO Athlete ( firstname, lastname, dateOfBirth)
                     VALUES ($firstname,$lastname,$dateOfBirth);
    """
	println 'inserted'
	db.close();
}
def findAll() {
	def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')	                                           //#2                                         //#4
    db.rows 'SELECT * FROM Athlete'
	db.close()
}
def updateFirstName(wrong, right) {                     //#5
	def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')	                                           //#2
    db.execute """
        UPDATE Athlete
           SET firstname = $right WHERE firstname = $wrong;
    """
	db.close()
}
def delete(firstname) {                                 //#6
	def db = Sql.newInstance('jdbc:mysql://localhost:3306/groovydb', 'root', 'zvarad123', 'com.mysql.jdbc.Driver')	                                           //#2
    db.execute "DELETE FROM Athlete WHERE firstname = $firstname;"
	db.close()
}

//reset()
assert ! findAll(), 'we are intially empty'
//create 'Maxx', 'Krish', '1979-04-19'
//assert 'Dirk'  == findAll()[0].firstname                //#7
updateFirstName  'Maxx', 'Madhu'
//assert 'Madhu' == findAll()[0].firstname
//delete 'Madhu'
assert ! findAll(), 'after delete, we are empty again'