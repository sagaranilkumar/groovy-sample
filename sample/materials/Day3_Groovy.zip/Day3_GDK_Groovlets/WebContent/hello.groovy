
// output some content

out << 'Hello, World!'